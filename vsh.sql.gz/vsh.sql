-- Adminer 4.8.1 MySQL 8.0.30 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_img',
  `info` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_id` bigint NOT NULL DEFAULT '1',
  `lessons` bigint NOT NULL DEFAULT '0',
  `techno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `tier` bigint NOT NULL DEFAULT '0',
  `step` bigint NOT NULL DEFAULT '0',
  `stat_reports` bigint NOT NULL DEFAULT '0',
  `stat_videos` bigint NOT NULL DEFAULT '0',
  `stat_stars` decimal(8,2) NOT NULL DEFAULT '0.00',
  `stat_lessons` bigint NOT NULL DEFAULT '0',
  `stat_duration` time NOT NULL,
  `is_active` int NOT NULL DEFAULT '0',
  `udemy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `courses` (`id`, `course`, `courl`, `img`, `info`, `access`, `author_id`, `lessons`, `techno`, `tier`, `step`, `stat_reports`, `stat_videos`, `stat_stars`, `stat_lessons`, `stat_duration`, `is_active`, `udemy`, `created_at`, `updated_at`) VALUES
(87,	'J1. Запуск',	'java-start',	'no_img',	'Знакомство с языком программирования Java - установка, компиляция, запуск.',	'club',	1,	4,	'java',	1,	1010,	439,	0,	4.83,	4,	'00:31:15',	0,	NULL,	NULL,	NULL),
(88,	'J2. Печать',	'java-write',	'no_img',	'Работа с операциями вывода на экран и форматированного вывода.',	'club',	1,	3,	'java',	1,	1020,	258,	0,	4.91,	3,	'00:09:54',	0,	NULL,	NULL,	NULL),
(89,	'J3. Ввод',	'java-read',	'no_img',	'Ввод текстовых и числовых данных с клавиатуры.',	'club',	1,	10,	'java',	1,	1030,	680,	0,	4.96,	10,	'00:12:26',	0,	NULL,	NULL,	NULL),
(90,	'J4. Типы',	'java-type',	'no_img',	'Обзор всех примитивных типов данных в языке Java.',	'club',	1,	4,	'java',	1,	1040,	227,	0,	4.99,	4,	'00:48:44',	0,	NULL,	NULL,	NULL),
(91,	'J5. Операции',	'java-oper',	'no_img',	'Обзор всех операций, разделение их по рангу выполнения.',	'club',	1,	7,	'java',	1,	1050,	356,	0,	4.99,	7,	'01:01:33',	0,	NULL,	NULL,	NULL),
(92,	'J6. Условия',	'java-if',	'no_img',	'Работа с условным оператором.',	'club',	1,	7,	'java',	1,	1060,	371,	0,	4.97,	8,	'00:18:31',	0,	NULL,	NULL,	NULL),
(93,	'J7. Экзамен',	'java-egz',	'no_img',	'Самостоятельное задание по первой части курса.',	'club',	1,	4,	'java',	1,	1070,	197,	0,	4.97,	5,	'00:00:00',	0,	NULL,	NULL,	NULL),
(94,	'J8. Циклопы',	'java-loop',	'no_img',	'Разновидности циклов, их использование.',	'club',	1,	10,	'java',	2,	2010,	458,	0,	4.99,	10,	'01:13:45',	0,	NULL,	NULL,	NULL),
(95,	'J9. Массивы',	'java-array',	'no_img',	'Знакомство с массивами.',	'club',	1,	3,	'java',	2,	2020,	158,	1,	5.00,	3,	'00:00:00',	0,	NULL,	NULL,	NULL),
(96,	'JA. Классные пакеты',	'java-class',	'no_img',	'Знакомство с классами и пакетами.',	'club',	1,	18,	'java',	2,	2030,	794,	1,	4.97,	18,	'00:59:15',	0,	NULL,	NULL,	NULL),
(97,	'JC. Явные графоциклы',	'java-for2d',	'no_img',	'Рисование графических узоров с использованием циклов.',	'club',	1,	11,	'java',	2,	2040,	377,	0,	4.99,	11,	'00:28:20',	0,	NULL,	NULL,	NULL),
(98,	'JB. Шахматные классы',	'java-chess',	'no_img',	'Создание классов для шахматных фигур.',	'club',	1,	6,	'java',	2,	2035,	233,	0,	5.00,	6,	'00:46:21',	0,	NULL,	NULL,	NULL),
(99,	'JD. Коллекции',	'java-list',	'no_img',	'Использование списков.',	'club',	1,	5,	'java',	2,	2050,	197,	0,	4.89,	5,	'01:28:02',	0,	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned DEFAULT '1',
  `lesson` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Название урока',
  `intro` text COLLATE utf8mb4_unicode_ci COMMENT 'Вступительный текст',
  `tasks` text COLLATE utf8mb4_unicode_ci COMMENT 'Домашнее задание по пунктам, каждый пункт на отдельной строке!',
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'youtube код видео',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'show / hide',
  `step` int DEFAULT '0' COMMENT 'Порядковый номер',
  `checking` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'need' COMMENT 'need / skip',
  `video_length` time DEFAULT NULL,
  `copy_id` int DEFAULT NULL,
  `demo` int DEFAULT '0',
  `need_lesson_ids` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tofill` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `packet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opencode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lesson_course_idx` (`course_id`),
  CONSTRAINT `lesson_course_fk` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `user_courses`;
CREATE TABLE `user_courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `courses_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_courses_user_idx` (`user_id`),
  KEY `user_courses_courses_idx` (`courses_id`),
  CONSTRAINT `user_courses_courses_fk` FOREIGN KEY (`courses_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `user_courses_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `videosharp_id` bigint DEFAULT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `uved_mess` tinyint(1) DEFAULT NULL,
  `uved_rep` tinyint(1) DEFAULT NULL,
  `uved_new` tinyint(1) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2023-03-12 15:56:28
